#ifndef __cplusplus
#error A C++ Compiler is required!
#endif
#include <iostream>
#include <string>
#include <ctime>
using namespace std;
#include "config"
#ifndef LANG
#define LANG "en-GB"//default language ;)
#endif
#include LANG //Includes a massive line of all the 4-letter words for the language that source file LANG is intended for (eg, use 'en-GB' for British English)
#ifndef WORD
#error in wordlist source file - no quantifier (WORD)
#endif

bool test(string in)
	{
		bool check = false;
		for(int count = 0; count < WORD; count++)
		{
			if (in.compare(words[count]) == 0 ) { check = true; }
		}
		return check;
	}

string * find(string in)
	{
		// now count all 4 letter words that can be made from in
		string cp = in;
		int tot = 0;
		for(int c = 0; c < 4; c++)
		{
			in = cp;
			if(test(in.replace(c,1,"a")) == true && in.replace(c,1,"a") != cp ) { tot++; }
			if(test(in.replace(c,1,"b")) == true && in.replace(c,1,"b") != cp ) { tot++; }
			if(test(in.replace(c,1,"c")) == true && in.replace(c,1,"c") != cp ) { tot++; }
			if(test(in.replace(c,1,"d")) == true && in.replace(c,1,"d") != cp ) { tot++; }
			if(test(in.replace(c,1,"e")) == true && in.replace(c,1,"e") != cp ) { tot++; }
			if(test(in.replace(c,1,"f")) == true && in.replace(c,1,"f") != cp ) { tot++; }
			if(test(in.replace(c,1,"g")) == true && in.replace(c,1,"g") != cp ) { tot++; }
			if(test(in.replace(c,1,"h")) == true && in.replace(c,1,"h") != cp ) { tot++; }
			if(test(in.replace(c,1,"i")) == true && in.replace(c,1,"i") != cp ) { tot++; }
			if(test(in.replace(c,1,"j")) == true && in.replace(c,1,"j") != cp ) { tot++; }
			if(test(in.replace(c,1,"k")) == true && in.replace(c,1,"k") != cp ) { tot++; }
			if(test(in.replace(c,1,"l")) == true && in.replace(c,1,"l") != cp ) { tot++; }
			if(test(in.replace(c,1,"m")) == true && in.replace(c,1,"m") != cp ) { tot++; }
			if(test(in.replace(c,1,"n")) == true && in.replace(c,1,"n") != cp ) { tot++; }
			if(test(in.replace(c,1,"o")) == true && in.replace(c,1,"o") != cp ) { tot++; }
			if(test(in.replace(c,1,"p")) == true && in.replace(c,1,"p") != cp ) { tot++; }
			if(test(in.replace(c,1,"q")) == true && in.replace(c,1,"q") != cp ) { tot++; }
			if(test(in.replace(c,1,"r")) == true && in.replace(c,1,"r") != cp ) { tot++; }
			if(test(in.replace(c,1,"s")) == true && in.replace(c,1,"s") != cp ) { tot++; }
			if(test(in.replace(c,1,"t")) == true && in.replace(c,1,"t") != cp ) { tot++; }
			if(test(in.replace(c,1,"u")) == true && in.replace(c,1,"u") != cp ) { tot++; }
			if(test(in.replace(c,1,"v")) == true && in.replace(c,1,"v") != cp ) { tot++; }
			if(test(in.replace(c,1,"w")) == true && in.replace(c,1,"w") != cp ) { tot++; }
			if(test(in.replace(c,1,"x")) == true && in.replace(c,1,"x") != cp ) { tot++; }
			if(test(in.replace(c,1,"y")) == true && in.replace(c,1,"y") != cp ) { tot++; }
			if(test(in.replace(c,1,"z")) == true && in.replace(c,1,"z") != cp ) { tot++; }
		}
		string * poss;
		poss = new string [tot+1];//create a dynamic array to store them in
		tot = 0;
		for(int c = 0; c < 4; c++)
		{
			in = cp;
			if(test(in.replace(c,1,"a")) == true && in.replace(c,1,"a") != cp ) { poss[tot] = in.replace(c,1,"a"); tot++; }
			if(test(in.replace(c,1,"b")) == true && in.replace(c,1,"b") != cp ) { poss[tot] = in.replace(c,1,"b"); tot++; }
			if(test(in.replace(c,1,"c")) == true && in.replace(c,1,"c") != cp ) { poss[tot] = in.replace(c,1,"c"); tot++; }
			if(test(in.replace(c,1,"d")) == true && in.replace(c,1,"d") != cp ) { poss[tot] = in.replace(c,1,"d"); tot++; }
			if(test(in.replace(c,1,"e")) == true && in.replace(c,1,"e") != cp ) { poss[tot] = in.replace(c,1,"e"); tot++; }
			if(test(in.replace(c,1,"f")) == true && in.replace(c,1,"f") != cp ) { poss[tot] = in.replace(c,1,"f"); tot++; }
			if(test(in.replace(c,1,"g")) == true && in.replace(c,1,"g") != cp ) { poss[tot] = in.replace(c,1,"g"); tot++; }
			if(test(in.replace(c,1,"h")) == true && in.replace(c,1,"h") != cp ) { poss[tot] = in.replace(c,1,"h"); tot++; }
			if(test(in.replace(c,1,"i")) == true && in.replace(c,1,"i") != cp ) { poss[tot] = in.replace(c,1,"i"); tot++; }
			if(test(in.replace(c,1,"j")) == true && in.replace(c,1,"j") != cp ) { poss[tot] = in.replace(c,1,"j"); tot++; }
			if(test(in.replace(c,1,"k")) == true && in.replace(c,1,"k") != cp ) { poss[tot] = in.replace(c,1,"k"); tot++; }
			if(test(in.replace(c,1,"l")) == true && in.replace(c,1,"l") != cp ) { poss[tot] = in.replace(c,1,"l"); tot++; }
			if(test(in.replace(c,1,"m")) == true && in.replace(c,1,"m") != cp ) { poss[tot] = in.replace(c,1,"m"); tot++; }
			if(test(in.replace(c,1,"n")) == true && in.replace(c,1,"n") != cp ) { poss[tot] = in.replace(c,1,"n"); tot++; }
			if(test(in.replace(c,1,"o")) == true && in.replace(c,1,"o") != cp ) { poss[tot] = in.replace(c,1,"o"); tot++; }
			if(test(in.replace(c,1,"p")) == true && in.replace(c,1,"p") != cp ) { poss[tot] = in.replace(c,1,"p"); tot++; }
			if(test(in.replace(c,1,"q")) == true && in.replace(c,1,"q") != cp ) { poss[tot] = in.replace(c,1,"q"); tot++; }
			if(test(in.replace(c,1,"r")) == true && in.replace(c,1,"r") != cp ) { poss[tot] = in.replace(c,1,"r"); tot++; }
			if(test(in.replace(c,1,"s")) == true && in.replace(c,1,"s") != cp ) { poss[tot] = in.replace(c,1,"s"); tot++; }
			if(test(in.replace(c,1,"t")) == true && in.replace(c,1,"t") != cp ) { poss[tot] = in.replace(c,1,"t"); tot++; }
			if(test(in.replace(c,1,"u")) == true && in.replace(c,1,"u") != cp ) { poss[tot] = in.replace(c,1,"u"); tot++; }
			if(test(in.replace(c,1,"v")) == true && in.replace(c,1,"v") != cp ) { poss[tot] = in.replace(c,1,"v"); tot++; }
			if(test(in.replace(c,1,"w")) == true && in.replace(c,1,"w") != cp ) { poss[tot] = in.replace(c,1,"w"); tot++; }
			if(test(in.replace(c,1,"x")) == true && in.replace(c,1,"x") != cp ) { poss[tot] = in.replace(c,1,"x"); tot++; }
			if(test(in.replace(c,1,"y")) == true && in.replace(c,1,"y") != cp ) { poss[tot] = in.replace(c,1,"y"); tot++; }
			if(test(in.replace(c,1,"z")) == true && in.replace(c,1,"z") != cp ) { poss[tot] = in.replace(c,1,"z"); tot++; }
		}
		poss[tot] = "!!!!";// "End of Array" tag, so we can get the size of the array
		return poss;
	}

string * cross(string * aArr, int aLen, string * zArr, int zLen, int mode)
	{
		//cross-reference the dynamic arrays aArr and zArr (where aLen and zLen are their sizes). Mode is how many characters in common to look for
		int tot = 0;
		for(int l = 0; l < aLen; l++)
		{
			for(int L = 0; L < zLen; L++)
			{
				int minc = 0;
				for(int mind = 0; mind < 4; mind++)
				{
					if(aArr[l].substr(mind,1) == zArr[L].substr(mind,1))
					{
						minc++;
					}
				}
				if(minc >= mode)
				{
					tot++;
				}
			}
		}
		string * poss;
		poss = new string [tot+1];//create a dynamic array to store them in
		tot = 0;
		for(int l = 0; l < aLen; l++)
		{
			for(int L = 0; L < zLen; L++)
			{
				int minc = 0;
				for(int mind = 0; mind < 4; mind++)
				{
					if(aArr[l].substr(mind,1) == zArr[L].substr(mind,1))
					{
						minc++;
					}
				}
				if(minc >= mode)
				{
					poss[tot] = aArr[l] + zArr[L];//combine matching pairs into 8-letter words, to make things a bit easier
					tot++;
				}
			}
		}
		poss[tot] = "!!!!";
		return poss;
	}

bool CROSS(string aArr, string zArr, int mode)
	{
		int minc = 0;
		for(int mind = 0; mind < 4; mind++)
			{
				if(aArr.substr(mind,1) == zArr.substr(mind,1))
				{
					minc++;
				}
			}
			if(minc >= mode)
			{
				return true;
			}
			else
			{
				return false;
			}
	}

int main (int argc, char* argv[])
{
	bool bevorse = false;
	bool all = false;
	bool html = false;
	for (int i = 1; i < argc; i++) {
		if (string(argv[i]) == "-h" ) {
			cout<<HELP<< endl;
			return 0;
		}
		if (string(argv[i]) == "-v" ) {
			bevorse = true;
		}
		if (string(argv[i]) == "-a" ) {
			all = true;
		}
		if (string(argv[i]) == "-H" ) {
			html = true;
		}
	}
	string a = argv[1];
	string z = argv[2]; // recieve inputs - the two words
	if (html == true) {
		cout<<"<!DOCTYPE html><html><head><title>Word ladder solution(s) for \""<<a<<"\" and \""<<z<<"\"</title></head><body>"<< endl;
	}
	if (bevorse == true) {
		if (html == true) {
			cout<<"<h1>"<< endl;
		}
		cout<<TITLE<<" v"<<VERSION<<"-"<<CHNG<< endl;
		if (html == true) {
			cout<<"</h1><h2>"<< endl;
		}
		cout<<"Written on "<<WRITTEN<<" by "<<ACKNOWLEDGE<< endl;
		if (html == true) {
			cout<<"</h2><h3>"<< endl;
		}
		cout<<"(last update: "<<UPDATED<<")\n\tCompiled for locale ["<<LANG<<"] at "<<__TIME__<<" on "<<__DATE__<< endl;
		if (html == true) {
			cout<<"</h3><p>"<< endl;
		}
		cout<<DESCRIPTION<< endl;
		if (html == true) {
			cout<<"</p>"<< endl;
		}
	}
	if (html == true) {
		cout<<"<h1>Word-ladder solutions for \""<<a<<"\" and \""<<z<<"\"</h1>"<< endl;
	}
	if (argc < 3) {
		cout<<"ERROR: Too few arguments"<< endl;
		cout<<HELP<< endl;
		return 2;
	}
	//SANITY CHECKING TO AVOID OUT OF BOUNDS ERRORS
	// next need to format the string a to four chars long
	a.resize(4,'?');
	if (html == true){ cout<<"<p>"<< endl; }
	if(bevorse){cout<<"Stage 1 of 4 - ";}
	if(test(a) == true)
	{
		if(bevorse){cout<<"Finding words 1 letter away from '"<<a<<"' ... ";}
		string * aPoss;
		aPoss = find(a);
		if(aPoss[0] != "!!!!")
		{
			int c = 0;
			do {
				c++;
			} while (aPoss[c] != "!!!!");
			if(bevorse){cout<<"\t\t\t[DONE] ";}
			if(bevorse){cout<<"("<<c<<")"<< endl;}
			if (html == true){ cout<<"</p><p>"<< endl; }
			// now do the same for string z
			z.resize(4,'?');
			if(bevorse){cout<<"Stage 2 of 4 - ";}
			if(test(z) == true)
			{
				if(bevorse){cout<<"Finding words 1 letter away from '"<<z<<"' ... ";}
				string * zPoss;
				zPoss = find(z);
				if(zPoss[0] != "!!!!")
				{
					int d = 0;
					do {
						d++;
					} while (zPoss[d] != "!!!!");
					if(bevorse){cout<<"\t\t\t[DONE] ";}
					if(bevorse){cout<<"("<<d<<")"<< endl;}
					if (html == true){ cout<<"</p><p>"<< endl; }
					//now we can cross-reference these lists of words, counting the words that have one letter in common with eachother
					if(bevorse){cout<<"Stage 3 of 4 - Cross-referencing words found from '"<<a<<"' and '"<<z<<"' ... ";}
					string * azPoss;
					azPoss = cross(aPoss,c,zPoss,d,1);
					int cd = 0;
					if (azPoss[cd] != "!!!!")
					{
						do {
							cd++;
						} while (azPoss[cd] != "!!!!");
						if(bevorse){cout<<"\t[DONE] ";}
						if(bevorse){cout<<"("<<cd<<")"<< endl;}
						if (html == true){ cout<<"</p><p>"<< endl; }
						//given that the possible pairs are already stored together, the rest isn't too hard.
						if(bevorse){cout<<"Stage 4 of 4 - Finding solutions ...";}
						//avg speed = 1262 solutions/second
						if(((cd*cd) >= (60*1262)) && html != true)
						{
							cout<<"(Max wait time: "<<(cd*cd)/1262<<" seconds) - Press ENTER\t[WORKING]"<< endl;
							cin.get();
						}
						else
						{
							if(bevorse){cout<<"\t\t\t\t\t\t[WORKING]"<< endl;}
						}
						if (html == true){ cout<<"</p>"<< endl; }
						int total = 0;
						if (html == true){ cout<<"<table border=\"1\">"<< endl; }
						for(int u = 0; u < cd; u++)
						{
							string * left;
							left = find(azPoss[u].substr(0,4));
							int lu = 0;
							while(left[lu] != "!!!!")
							{
								lu++;
							}
							string * right;
							right = find(azPoss[u].substr(4,4));
							int ru = 0;
							while(right[ru] != "!!!!")
							{
								ru++;
							}
							for(int nl = 0; nl < lu; nl++)
							{
								for(int nr = 0; nr < ru; nr++)
								{
									if(CROSS(left[nl],right[nr],3) == true)
									{
										if (html == true){ cout<<"<tr><td>"<< endl; }
										cout<<a<<"\t";
										if (html == true){ cout<<"</td><td>"<< endl; }
										cout<<azPoss[u].substr(0,4);
										if (html == true){ cout<<"</td><td>"<< endl; }
										cout<<"\t"<<left[nl];
										if (html == true){ cout<<"</td><td>"<< endl; }
										cout<<"\t"<<right[nr];
										if (html == true){ cout<<"</td><td>"<< endl; }
										cout<<"\t"<<azPoss[u].substr(4,4)<<"\t";
										if (html == true){ cout<<"</td><td>"<< endl; }
										cout<<z;
										if (html == true){ cout<<"</td></tr>"<< endl; }
if(bevorse && (html != true)){cout<<"\t\t\t\t\t[WORKING]"<< endl;}
if(not bevorse){cout<<" "<< endl;}
										total++;
										if (not all) {
											nl = lu;
											nr = ru;
											u = cd;
										}
									}
								}
							}
						}
						if (html == true){ cout<<"</table>"<< endl; }
						if(total > 0)
						{
							if(bevorse){cout<<"Success! Found "<<total<<" solutions to the puzzle.\t\t\t\t\t[DONE] ("<<total<<")"<< endl;}
							if (html == true) {
								cout<<"</body></html>"<< endl;
							}
							return 0;
						}
						else
						{
							cout<<"No solutions could be found.\t\t\t\t\t\t\t[FAIL] (0)"<< endl;
							if (html == true) {
								cout<<"</body></html>"<< endl;
							}
							return 1;
						}
					}
					else
					{
						cout<<"\t[FAIL] - No cross-references found (0)"<< endl;
						if (html == true) {
							cout<<"</body></html>"<< endl;
						}
						return 1;
					}
				}
				else
				{
					cout<<"\t\t\t[FAIL] - No words found (0)"<< endl;
					if (html == true) {
						cout<<"</body></html>"<< endl;
					}	
					return 1;
				}
			}
			else
			{
				cout<<"ERROR! '"<<z<<"' is not an entry in the wordlist!\t\t\t[FAIL]"<< endl;
				if (html == true) {
					cout<<"</body></html>"<< endl;
				}
				return 2;
			}
		}
		else
		{
			cout<<"\t\t\t[FAIL] - No words found (0)"<< endl;
			if (html == true) {
				cout<<"</body></html>"<< endl;
			}
			return 1;
		}
	}	
	else
	{
		cout<<"ERROR! '"<<a<<"' is not an entry in the wordlist!\t\t\t[FAIL]"<< endl;
		if (html == true) {
			cout<<"</body></html>"<< endl;
		}
		return 2;
	}
}
